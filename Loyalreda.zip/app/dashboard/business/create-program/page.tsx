"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Switch } from "@/components/ui/switch"
import { useAuth } from "@/components/auth/auth-provider"

const formSchema = z.object({
  programName: z.string().min(3, { message: "Program name must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  pointsPerPurchase: z.coerce.number().min(1, { message: "Must be at least 1" }),
  spendAmount: z.coerce.number().min(1, { message: "Must be at least 1" }),
  pointsForReward: z.coerce.number().min(1, { message: "Must be at least 1" }),
  rewardDescription: z.string().min(5, { message: "Reward description must be at least 5 characters" }),
  rewardValue: z.coerce.number().min(1, { message: "Must be at least 1" }),
  category: z.string().min(1, { message: "Please select a category" }),
  isActive: z.boolean().default(true),
  expiryDays: z.coerce.number().min(0, { message: "Must be 0 or greater" }).default(0),
})

export default function CreateLoyaltyProgramPage() {
  const { toast } = useToast()
  const router = useRouter()
  const { user } = useAuth()
  const [isLoading, setIsLoading] = useState(false)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      programName: "",
      description: "",
      pointsPerPurchase: 1,
      spendAmount: 10,
      pointsForReward: 10,
      rewardDescription: "",
      rewardValue: 5,
      category: "",
      isActive: true,
      expiryDays: 365,
    },
  })

  async function onSubmit(values: z.infer<typeof formSchema>) {
    if (!user || user.role !== "business") {
      toast({
        variant: "destructive",
        title: "Unauthorized",
        description: "You must be logged in as a business to create a loyalty program.",
      })
      return
    }

    setIsLoading(true)
    try {
      // API call would go here
      console.log("Creating loyalty program:", values)

      toast({
        title: "Program created",
        description: "Your loyalty program has been created successfully.",
      })
      router.push("/dashboard/business/programs")
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to create program",
        description: "There was an error creating your loyalty program. Please try again.",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (!user || user.role !== "business") {
    return (
      <div className="container flex h-[calc(100vh-200px)] items-center justify-center">
        <Card className="mx-auto w-full max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>Only business accounts can create loyalty programs</CardDescription>
          </CardHeader>
        </Card>
      </div>
    )
  }

  return (
    <div className="container py-8">
      <div className="mx-auto max-w-3xl">
        <h1 className="mb-6 text-3xl font-bold">Create Loyalty Program</h1>
        <Card>
          <CardHeader>
            <CardTitle>Program Details</CardTitle>
            <CardDescription>
              Set up your loyalty program details. Customers will earn points based on their purchases.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="programName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Program Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Coffee Rewards" {...field} />
                        </FormControl>
                        <FormDescription>A catchy name for your loyalty program</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Food & Beverage">Food & Beverage</SelectItem>
                            <SelectItem value="Retail">Retail</SelectItem>
                            <SelectItem value="Fitness">Fitness</SelectItem>
                            <SelectItem value="Electronics">Electronics</SelectItem>
                            <SelectItem value="Beauty">Beauty</SelectItem>
                            <SelectItem value="Health">Health</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription>The category your program belongs to</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Program Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Earn points with every purchase and redeem for free items"
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>Explain how your loyalty program works</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid gap-6 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="pointsPerPurchase"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Points Per Purchase</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" {...field} />
                        </FormControl>
                        <FormDescription>How many points customers earn</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="spendAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Spend Amount (MAD)</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" {...field} />
                        </FormControl>
                        <FormDescription>Amount spent to earn points</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid gap-6 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="pointsForReward"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Points Needed for Reward</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" {...field} />
                        </FormControl>
                        <FormDescription>Points needed to redeem a reward</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="rewardValue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reward Value (MAD)</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" {...field} />
                        </FormControl>
                        <FormDescription>The monetary value of the reward</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="rewardDescription"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reward Description</FormLabel>
                      <FormControl>
                        <Input placeholder="Free coffee or 10 MAD discount" {...field} />
                      </FormControl>
                      <FormDescription>Describe what customers get as a reward</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid gap-6 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="expiryDays"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Points Expiry (Days)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" {...field} />
                        </FormControl>
                        <FormDescription>0 means points never expire</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Active Status</FormLabel>
                          <FormDescription>Make this program available to customers</FormDescription>
                        </div>
                        <FormControl>
                          <Switch checked={field.value} onCheckedChange={field.onChange} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end space-x-4">
                  <Button variant="outline" type="button" onClick={() => router.back()}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? "Creating..." : "Create Program"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

