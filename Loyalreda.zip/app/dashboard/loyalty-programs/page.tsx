"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/components/auth/auth-provider"
import { Badge } from "@/components/ui/badge"
import { Search } from "lucide-react"

// Mock data for loyalty programs
const mockLoyaltyPrograms = [
  {
    id: "1",
    businessName: "Coffee Haven",
    description: "Earn 1 point for every $5 spent. 10 points = free coffee.",
    pointsEarned: 7,
    pointsNeeded: 10,
    reward: "Free coffee",
    category: "Food & Beverage",
  },
  {
    id: "2",
    businessName: "Bookworm's Paradise",
    description: "Earn 1 point for every book purchased. 5 points = $10 discount.",
    pointsEarned: 3,
    pointsNeeded: 5,
    reward: "$10 discount",
    category: "Retail",
  },
  {
    id: "3",
    businessName: "Fitness First",
    description: "Earn 5 points for every class. 20 points = free personal training session.",
    pointsEarned: 15,
    pointsNeeded: 20,
    reward: "Free personal training",
    category: "Fitness",
  },
  {
    id: "4",
    businessName: "Tech Galaxy",
    description: "Earn 2 points for every $50 spent. 20 points = $25 discount.",
    pointsEarned: 8,
    pointsNeeded: 20,
    reward: "$25 discount",
    category: "Electronics",
  },
]

export default function LoyaltyProgramsPage() {
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  const filteredPrograms = mockLoyaltyPrograms.filter((program) => {
    const matchesSearch =
      program.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      program.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      program.category.toLowerCase().includes(searchTerm.toLowerCase())

    if (activeTab === "all") return matchesSearch
    return matchesSearch && program.category.toLowerCase() === activeTab.toLowerCase()
  })

  if (!user) {
    return (
      <div className="container flex h-[calc(100vh-200px)] items-center justify-center">
        <Card className="mx-auto w-full max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>Please log in to view loyalty programs</CardDescription>
          </CardHeader>
        </Card>
      </div>
    )
  }

  return (
    <div className="container py-8">
      <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-3xl font-bold">Loyalty Programs</h1>
          <p className="text-muted-foreground">Discover and join loyalty programs from your favorite businesses</p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search programs..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-6 w-full justify-start overflow-auto">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="Food & Beverage">Food & Beverage</TabsTrigger>
          <TabsTrigger value="Retail">Retail</TabsTrigger>
          <TabsTrigger value="Fitness">Fitness</TabsTrigger>
          <TabsTrigger value="Electronics">Electronics</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-0">
          {filteredPrograms.length === 0 ? (
            <div className="flex h-40 flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
              <p className="text-muted-foreground">No loyalty programs found matching your criteria</p>
              <Button
                variant="link"
                onClick={() => {
                  setSearchTerm("")
                  setActiveTab("all")
                }}
              >
                Clear filters
              </Button>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredPrograms.map((program) => (
                <Card key={program.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle>{program.businessName}</CardTitle>
                        <CardDescription className="mt-1">{program.description}</CardDescription>
                      </div>
                      <Badge variant="outline">{program.category}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <p className="mb-2 text-sm font-medium">Progress to {program.reward}</p>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-primary/20">
                        <div
                          className="h-full bg-primary"
                          style={{ width: `${(program.pointsEarned / program.pointsNeeded) * 100}%` }}
                        ></div>
                      </div>
                      <p className="mt-2 text-sm text-muted-foreground">
                        {program.pointsEarned} / {program.pointsNeeded} points
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter className="border-t bg-muted/50 px-6 py-3">
                    <Button asChild variant="outline" size="sm" className="w-full">
                      <Link href={`/dashboard/loyalty-programs/${program.id}`}>View Details</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

