import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Award, BarChart3, Shield } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary/10 via-primary/5 to-background px-4 py-24 md:px-6 lg:py-32">
        <div className="container mx-auto grid max-w-6xl gap-12 md:grid-cols-2 md:gap-16">
          <div className="flex flex-col justify-center space-y-4">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">Reward Your Loyal Customers</h1>
            <p className="max-w-[600px] text-muted-foreground md:text-xl">
              Create custom loyalty programs that keep customers coming back. Easy to set up, easy to manage.
            </p>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button asChild size="lg">
                <Link href="/register?type=business">
                  Register Your Business <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/register?type=customer">Join as a Customer</Link>
              </Button>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative h-[350px] w-[350px] rounded-full bg-primary/10 p-4">
              <div className="absolute left-1/2 top-1/2 h-[300px] w-[300px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/20"></div>
              <div className="absolute left-1/2 top-1/2 h-[250px] w-[250px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/30"></div>
              <div className="absolute left-1/2 top-1/2 flex h-[200px] w-[200px] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-primary text-4xl font-bold text-primary-foreground">
                LOYALTY
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="px-4 py-16 md:px-6 lg:py-24">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How It Works</h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-xl">
              Our platform makes it easy to create, manage, and grow your loyalty program
            </p>
          </div>
          <div className="grid gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 text-center">
              <div className="rounded-full bg-primary/10 p-4">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Easy Registration</h3>
              <p className="text-muted-foreground">
                Sign up your business in minutes and start creating custom loyalty programs tailored to your customers.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 text-center">
              <div className="rounded-full bg-primary/10 p-4">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Flexible Rewards</h3>
              <p className="text-muted-foreground">
                Create custom loyalty deals with flexible reward tiers that match your business goals and customer
                expectations.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-4 rounded-lg border p-6 text-center">
              <div className="rounded-full bg-primary/10 p-4">
                <BarChart3 className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Detailed Analytics</h3>
              <p className="text-muted-foreground">
                Track customer engagement, redemption rates, and program performance with our comprehensive analytics
                dashboard.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-muted px-4 py-16 md:px-6 lg:py-24">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">What Our Users Say</h2>
            <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-xl">
              Businesses and customers love our platform
            </p>
          </div>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-lg bg-background p-6 shadow">
              <p className="mb-4 text-muted-foreground">
                "Since implementing this loyalty program, we've seen a 30% increase in repeat customers. The platform is
                intuitive and our customers love it!"
              </p>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-primary/20"></div>
                <div>
                  <p className="font-medium">Sarah Johnson</p>
                  <p className="text-sm text-muted-foreground">Café Owner</p>
                </div>
              </div>
            </div>
            <div className="rounded-lg bg-background p-6 shadow">
              <p className="mb-4 text-muted-foreground">
                "I love collecting points at my favorite stores. The app makes it easy to track my rewards and redeem
                them."
              </p>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-primary/20"></div>
                <div>
                  <p className="font-medium">Michael Chen</p>
                  <p className="text-sm text-muted-foreground">Customer</p>
                </div>
              </div>
            </div>
            <div className="rounded-lg bg-background p-6 shadow">
              <p className="mb-4 text-muted-foreground">
                "The analytics dashboard gives me valuable insights into customer behavior. It's helped us optimize our
                loyalty program for better results."
              </p>
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-primary/20"></div>
                <div>
                  <p className="font-medium">Aisha Patel</p>
                  <p className="text-sm text-muted-foreground">Retail Manager</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-16 md:px-6 lg:py-24">
        <div className="container mx-auto max-w-6xl">
          <div className="rounded-lg bg-primary p-8 text-center text-primary-foreground md:p-12">
            <h2 className="mb-4 text-3xl font-bold tracking-tighter sm:text-4xl">Ready to Get Started?</h2>
            <p className="mx-auto mb-6 max-w-[600px] text-primary-foreground/90 md:text-lg">
              Join thousands of businesses already growing with our loyalty platform
            </p>
            <div className="flex flex-col justify-center gap-4 sm:flex-row">
              <Button asChild size="lg" variant="secondary">
                <Link href="/register?type=business">Register Your Business</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-transparent text-primary-foreground">
                <Link href="/login">Sign In</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Blog Preview Section */}
      <section className="px-4 py-16 md:px-6 lg:py-24">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-12 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Latest from Our Blog</h2>
              <p className="mt-2 text-muted-foreground">Tips and insights on customer loyalty and retention</p>
            </div>
            <Button asChild variant="outline">
              <Link href="/blog">View All Posts</Link>
            </Button>
          </div>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="group rounded-lg border">
              <div className="aspect-video w-full overflow-hidden rounded-t-lg bg-muted"></div>
              <div className="p-6">
                <p className="mb-2 text-sm text-muted-foreground">March 15, 2024</p>
                <h3 className="mb-2 text-xl font-bold group-hover:text-primary">
                  <Link href="/blog/1">5 Ways to Improve Customer Retention with Loyalty Programs</Link>
                </h3>
                <p className="mb-4 text-muted-foreground">
                  Learn how to design loyalty programs that keep customers coming back for more.
                </p>
                <Link href="/blog/1" className="text-sm font-medium text-primary hover:underline">
                  Read More →
                </Link>
              </div>
            </div>
            <div className="group rounded-lg border">
              <div className="aspect-video w-full overflow-hidden rounded-t-lg bg-muted"></div>
              <div className="p-6">
                <p className="mb-2 text-sm text-muted-foreground">March 8, 2024</p>
                <h3 className="mb-2 text-xl font-bold group-hover:text-primary">
                  <Link href="/blog/2">The Psychology Behind Successful Loyalty Programs</Link>
                </h3>
                <p className="mb-4 text-muted-foreground">
                  Understand the psychological principles that make loyalty programs effective.
                </p>
                <Link href="/blog/2" className="text-sm font-medium text-primary hover:underline">
                  Read More →
                </Link>
              </div>
            </div>
            <div className="group rounded-lg border">
              <div className="aspect-video w-full overflow-hidden rounded-t-lg bg-muted"></div>
              <div className="p-6">
                <p className="mb-2 text-sm text-muted-foreground">March 1, 2024</p>
                <h3 className="mb-2 text-xl font-bold group-hover:text-primary">
                  <Link href="/blog/3">How to Measure the ROI of Your Loyalty Program</Link>
                </h3>
                <p className="mb-4 text-muted-foreground">
                  Discover the key metrics to track when evaluating your loyalty program's performance.
                </p>
                <Link href="/blog/3" className="text-sm font-medium text-primary hover:underline">
                  Read More →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

