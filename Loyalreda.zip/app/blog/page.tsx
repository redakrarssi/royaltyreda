import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

// Mock blog posts data
const blogPosts = [
  {
    id: "1",
    title: "5 Ways to Improve Customer Retention with Loyalty Programs",
    excerpt:
      "Learn how to design loyalty programs that keep customers coming back for more. Discover the key elements that make loyalty programs effective.",
    date: "March 15, 2024",
    author: "Jane Smith",
    authorRole: "Marketing Director",
    category: "Customer Retention",
    readTime: "5 min read",
  },
  {
    id: "2",
    title: "The Psychology Behind Successful Loyalty Programs",
    excerpt:
      "Understand the psychological principles that make loyalty programs effective. Learn how to leverage these principles to create more engaging programs.",
    date: "March 8, 2024",
    author: "David Johnson",
    authorRole: "Customer Experience Specialist",
    category: "Psychology",
    readTime: "7 min read",
  },
  {
    id: "3",
    title: "How to Measure the ROI of Your Loyalty Program",
    excerpt:
      "Discover the key metrics to track when evaluating your loyalty program's performance. Learn how to calculate the true ROI of your customer retention efforts.",
    date: "March 1, 2024",
    author: "Michael Chen",
    authorRole: "Data Analyst",
    category: "Analytics",
    readTime: "6 min read",
  },
  {
    id: "4",
    title: "Building a Loyalty Program on a Budget",
    excerpt:
      "You don't need a massive budget to create an effective loyalty program. Learn how small businesses can implement cost-effective loyalty solutions.",
    date: "February 22, 2024",
    author: "Sarah Williams",
    authorRole: "Small Business Consultant",
    category: "Small Business",
    readTime: "4 min read",
  },
  {
    id: "5",
    title: "Digital vs. Physical Loyalty Cards: Which is Right for Your Business?",
    excerpt:
      "Compare the pros and cons of digital and physical loyalty programs. Find out which option aligns best with your business goals and customer preferences.",
    date: "February 15, 2024",
    author: "Alex Rodriguez",
    authorRole: "Technology Consultant",
    category: "Technology",
    readTime: "5 min read",
  },
  {
    id: "6",
    title: "Case Study: How Restaurant X Increased Repeat Visits by 40%",
    excerpt:
      "A detailed look at how Restaurant X redesigned their loyalty program and achieved remarkable results in customer retention and revenue growth.",
    date: "February 8, 2024",
    author: "Emily Parker",
    authorRole: "Restaurant Industry Analyst",
    category: "Case Study",
    readTime: "8 min read",
  },
]

export default function BlogPage() {
  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Loyalty Program Blog</h1>
        <p className="text-muted-foreground">
          Insights, tips, and best practices for creating effective loyalty programs
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {blogPosts.map((post) => (
          <Card key={post.id} className="flex flex-col">
            <CardHeader className="pb-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>{post.category}</span>
                <span>•</span>
                <span>{post.readTime}</span>
              </div>
              <CardTitle className="line-clamp-2 hover:text-primary">
                <Link href={`/blog/${post.id}`}>{post.title}</Link>
              </CardTitle>
              <CardDescription className="line-clamp-3">{post.excerpt}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <div className="h-40 rounded-md bg-muted"></div>
            </CardContent>
            <CardFooter className="flex flex-col items-start border-t pt-4">
              <div className="mb-2 flex items-center gap-2">
                <div className="h-8 w-8 rounded-full bg-muted"></div>
                <div>
                  <p className="text-sm font-medium">{post.author}</p>
                  <p className="text-xs text-muted-foreground">{post.authorRole}</p>
                </div>
              </div>
              <div className="flex w-full items-center justify-between">
                <p className="text-sm text-muted-foreground">{post.date}</p>
                <Button asChild variant="ghost" size="sm">
                  <Link href={`/blog/${post.id}`}>Read More</Link>
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

