"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useAuth } from "@/components/auth/auth-provider"
import { Award, ChevronDown, LogOut, Menu, User } from "lucide-react"

export default function Header() {
  const pathname = usePathname()
  const { user, logout } = useAuth()
  const [isOpen, setIsOpen] = useState(false)

  const isActive = (path: string) => {
    return pathname === path
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <Award className="h-6 w-6 text-primary" />
            <span className="text-lg font-bold">LoyaltyHub</span>
          </Link>
          <nav className="hidden md:flex md:gap-6">
            <Link
              href="/"
              className={`text-sm font-medium ${
                isActive("/") ? "text-foreground" : "text-muted-foreground"
              } transition-colors hover:text-foreground`}
            >
              Home
            </Link>
            <Link
              href="/blog"
              className={`text-sm font-medium ${
                isActive("/blog") ? "text-foreground" : "text-muted-foreground"
              } transition-colors hover:text-foreground`}
            >
              Blog
            </Link>
            {user && (
              <Link
                href="/dashboard"
                className={`text-sm font-medium ${
                  pathname.startsWith("/dashboard") ? "text-foreground" : "text-muted-foreground"
                } transition-colors hover:text-foreground`}
              >
                Dashboard
              </Link>
            )}
            {user && user.role === "customer" && (
              <Link
                href="/dashboard/loyalty-programs"
                className={`text-sm font-medium ${
                  pathname.startsWith("/dashboard/loyalty-programs") ? "text-foreground" : "text-muted-foreground"
                } transition-colors hover:text-foreground`}
              >
                Programs
              </Link>
            )}
          </nav>
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <>
              <div className="hidden md:block">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      <span>{user.name}</span>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard">Dashboard</Link>
                    </DropdownMenuItem>
                    {user.role === "business" && (
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard/business/programs">My Programs</Link>
                      </DropdownMenuItem>
                    )}
                    {user.role === "customer" && (
                      <DropdownMenuItem asChild>
                        <Link href="/dashboard/loyalty-programs">Loyalty Programs</Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout} className="text-destructive">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <Sheet open={isOpen} onOpenChange={setIsOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col gap-4 py-4">
                    <Link href="/" className="text-sm font-medium" onClick={() => setIsOpen(false)}>
                      Home
                    </Link>
                    <Link href="/blog" className="text-sm font-medium" onClick={() => setIsOpen(false)}>
                      Blog
                    </Link>
                    <Link href="/dashboard" className="text-sm font-medium" onClick={() => setIsOpen(false)}>
                      Dashboard
                    </Link>
                    {user.role === "customer" && (
                      <Link
                        href="/dashboard/loyalty-programs"
                        className="text-sm font-medium"
                        onClick={() => setIsOpen(false)}
                      >
                        Programs
                      </Link>
                    )}
                    <Button variant="ghost" onClick={logout} className="justify-start px-0">
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Log out</span>
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </>
          ) : (
            <>
              <div className="hidden md:flex md:gap-2">
                <Button asChild variant="ghost">
                  <Link href="/login">Sign in</Link>
                </Button>
                <Button asChild>
                  <Link href="/register">Sign up</Link>
                </Button>
              </div>
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col gap-4 py-4">
                    <Link href="/" className="text-sm font-medium">
                      Home
                    </Link>
                    <Link href="/blog" className="text-sm font-medium">
                      Blog
                    </Link>
                    <Link href="/login" className="text-sm font-medium">
                      Sign in
                    </Link>
                    <Link href="/register" className="text-sm font-medium">
                      Sign up
                    </Link>
                  </div>
                </SheetContent>
              </Sheet>
            </>
          )}
        </div>
      </div>
    </header>
  )
}

