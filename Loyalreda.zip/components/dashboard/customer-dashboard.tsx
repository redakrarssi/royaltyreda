import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Award, CreditCard, History, Star } from "lucide-react"

// Mock data for customer dashboard
const mockLoyaltyCards = [
  {
    id: "1",
    businessName: "Coffee Haven",
    points: 7,
    totalPoints: 10,
    reward: "Free coffee",
    lastVisit: "2 days ago",
  },
  {
    id: "2",
    businessName: "Bookworm's Paradise",
    points: 3,
    totalPoints: 5,
    reward: "$10 discount",
    lastVisit: "1 week ago",
  },
  {
    id: "3",
    businessName: "Fitness First",
    points: 15,
    totalPoints: 20,
    reward: "Free personal training",
    lastVisit: "3 days ago",
  },
]

const mockTransactions = [
  {
    id: "1",
    businessName: "Coffee Haven",
    date: "Mar 15, 2024",
    amount: 12.5,
    pointsEarned: 2,
  },
  {
    id: "2",
    businessName: "Fitness First",
    date: "Mar 13, 2024",
    amount: 25.0,
    pointsEarned: 5,
  },
  {
    id: "3",
    businessName: "Coffee Haven",
    date: "Mar 10, 2024",
    amount: 8.75,
    pointsEarned: 1,
  },
  {
    id: "4",
    businessName: "Bookworm's Paradise",
    date: "Mar 5, 2024",
    amount: 32.99,
    pointsEarned: 3,
  },
]

const mockRewards = [
  {
    id: "1",
    businessName: "Coffee Haven",
    reward: "Free coffee",
    expiryDate: "Apr 30, 2024",
    status: "Available",
  },
  {
    id: "2",
    businessName: "Fitness First",
    reward: "50% off next class",
    expiryDate: "Apr 15, 2024",
    status: "Available",
  },
  {
    id: "3",
    businessName: "Bookworm's Paradise",
    reward: "$10 discount",
    expiryDate: "Mar 1, 2024",
    status: "Expired",
  },
]

export function CustomerDashboard({ user }: { user: any }) {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Welcome back, {user.name}</h1>
        <p className="text-muted-foreground">Manage your loyalty programs and rewards</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Points</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">125</div>
            <p className="text-xs text-muted-foreground">Across all programs</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Programs</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">Enrolled loyalty programs</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available Rewards</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">Ready to redeem</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="loyalty-cards" className="mt-8">
        <TabsList>
          <TabsTrigger value="loyalty-cards">My Loyalty Cards</TabsTrigger>
          <TabsTrigger value="transactions">Recent Transactions</TabsTrigger>
          <TabsTrigger value="rewards">My Rewards</TabsTrigger>
        </TabsList>
        <TabsContent value="loyalty-cards" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {mockLoyaltyCards.map((card) => (
              <Card key={card.id}>
                <CardHeader>
                  <CardTitle>{card.businessName}</CardTitle>
                  <CardDescription>Last visit: {card.lastVisit}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <p className="mb-2 text-sm font-medium">Progress to {card.reward}</p>
                    <div className="h-2 w-full overflow-hidden rounded-full bg-primary/20">
                      <div
                        className="h-full bg-primary"
                        style={{ width: `${(card.points / card.totalPoints) * 100}%` }}
                      ></div>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      {card.points} / {card.totalPoints} points
                    </p>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" size="sm" className="w-full">
                    <Link href={`/dashboard/loyalty-programs/${card.id}`}>View Details</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
            <Card className="flex flex-col items-center justify-center p-6">
              <div className="mb-4 rounded-full bg-muted p-3">
                <Award className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-medium">Discover More Programs</h3>
              <p className="mb-4 text-center text-sm text-muted-foreground">
                Find and join loyalty programs from your favorite businesses
              </p>
              <Button asChild>
                <Link href="/dashboard/loyalty-programs">Browse Programs</Link>
              </Button>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="transactions" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Your recent purchases and points earned</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {mockTransactions.map((transaction) => (
                  <div key={transaction.id} className="flex items-center">
                    <div className="mr-4 rounded-full bg-primary/10 p-2">
                      <History className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <p className="text-sm font-medium leading-none">{transaction.businessName}</p>
                      <p className="text-sm text-muted-foreground">{transaction.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">${transaction.amount.toFixed(2)}</p>
                      <p className="text-sm text-muted-foreground">+{transaction.pointsEarned} points</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" size="sm" className="w-full">
                View All Transactions
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="rewards" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>My Rewards</CardTitle>
              <CardDescription>Rewards you've earned from loyalty programs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockRewards.map((reward) => (
                  <div
                    key={reward.id}
                    className={`flex items-center justify-between rounded-lg border p-4 ${
                      reward.status === "Expired" ? "opacity-60" : ""
                    }`}
                  >
                    <div className="space-y-1">
                      <p className="font-medium">{reward.reward}</p>
                      <p className="text-sm text-muted-foreground">{reward.businessName}</p>
                      <p className="text-sm text-muted-foreground">Expires: {reward.expiryDate}</p>
                    </div>
                    <div>
                      {reward.status === "Available" ? (
                        <Button size="sm">Redeem</Button>
                      ) : (
                        <span className="text-sm text-muted-foreground">Expired</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

