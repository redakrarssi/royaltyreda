import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Award, BarChart3, Plus, Users } from "lucide-react"

// Mock data for business dashboard
const mockPrograms = [
  {
    id: "1",
    name: "Coffee Rewards",
    customers: 124,
    pointsIssued: 1250,
    redemptions: 45,
    status: "Active",
  },
  {
    id: "2",
    name: "VIP Customer Program",
    customers: 56,
    pointsIssued: 840,
    redemptions: 12,
    status: "Active",
  },
]

const mockRedemptions = [
  {
    id: "1",
    customerName: "John Smith",
    program: "Coffee Rewards",
    reward: "Free coffee",
    date: "Mar 15, 2024",
    status: "Completed",
  },
  {
    id: "2",
    customerName: "Sarah Johnson",
    program: "VIP Customer Program",
    reward: "10% discount",
    date: "Mar 14, 2024",
    status: "Completed",
  },
  {
    id: "3",
    customerName: "Michael Brown",
    program: "Coffee Rewards",
    reward: "Free coffee",
    date: "Mar 12, 2024",
    status: "Completed",
  },
]

export function BusinessDashboard({ user }: { user: any }) {
  return (
    <div>
      <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-3xl font-bold">Business Dashboard</h1>
          <p className="text-muted-foreground">Manage your loyalty programs and customer rewards</p>
        </div>
        <Button asChild>
          <Link href="/dashboard/business/create-program">
            <Plus className="mr-2 h-4 w-4" /> Create Program
          </Link>
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">180</div>
            <p className="text-xs text-muted-foreground">+12 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Programs</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">Across all locations</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Redemptions</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">57</div>
            <p className="text-xs text-muted-foreground">+8 from last month</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="programs" className="mt-8">
        <TabsList>
          <TabsTrigger value="programs">My Programs</TabsTrigger>
          <TabsTrigger value="redemptions">Recent Redemptions</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>
        <TabsContent value="programs" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {mockPrograms.map((program) => (
              <Card key={program.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{program.name}</CardTitle>
                    <span
                      className={`rounded-full px-2 py-1 text-xs font-medium ${
                        program.status === "Active" ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800"
                      }`}
                    >
                      {program.status}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Customers:</span>
                      <span className="text-sm font-medium">{program.customers}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Points Issued:</span>
                      <span className="text-sm font-medium">{program.pointsIssued}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Redemptions:</span>
                      <span className="text-sm font-medium">{program.redemptions}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/dashboard/business/programs/${program.id}`}>View Details</Link>
                  </Button>
                  <Button asChild variant="ghost" size="sm">
                    <Link href={`/dashboard/business/programs/${program.id}/edit`}>Edit</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
            <Card className="flex flex-col items-center justify-center p-6">
              <div className="mb-4 rounded-full bg-muted p-3">
                <Plus className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-xl font-medium">Create New Program</h3>
              <p className="mb-4 text-center text-sm text-muted-foreground">
                Set up a new loyalty program for your customers
              </p>
              <Button asChild>
                <Link href="/dashboard/business/create-program">Create Program</Link>
              </Button>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="redemptions" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Redemptions</CardTitle>
              <CardDescription>Customer reward redemptions from your loyalty programs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {mockRedemptions.map((redemption) => (
                  <div key={redemption.id} className="flex items-center">
                    <div className="mr-4 rounded-full bg-primary/10 p-2">
                      <Award className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <p className="text-sm font-medium leading-none">{redemption.customerName}</p>
                      <p className="text-sm text-muted-foreground">
                        {redemption.program} - {redemption.reward}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{redemption.status}</p>
                      <p className="text-sm text-muted-foreground">{redemption.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" size="sm" className="w-full">
                View All Redemptions
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="analytics" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Program Analytics</CardTitle>
              <CardDescription>Performance metrics for your loyalty programs</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px]">
              <div className="flex h-full items-center justify-center">
                <p className="text-muted-foreground">Analytics charts will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

